func PSD(){
    var Slicesleft = 8
    var user1slice = 2
    Slicesleft = Slicesleft - user1slice
    if Slicesleft <= 0 {
        print("you took too many slices user 1")
    }
    var user2slice = 3
    Slicesleft = Slicesleft - user2slice
    if Slicesleft <= 0 {
        print("you took too many slices user 2")
    }
    var user3slice = 1
    Slicesleft = Slicesleft - user3slice
    if Slicesleft <= 0 {
        print("you took too many slices user 3")
    }
    var user4slice = 3
    Slicesleft = Slicesleft - user4slice
    if Slicesleft <= 0{
        print("you took too many slices user 4")
    }
} 
